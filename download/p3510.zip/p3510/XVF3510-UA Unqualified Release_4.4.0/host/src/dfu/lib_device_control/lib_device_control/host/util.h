// Copyright (c) 2016-2017, XMOS Ltd, All rights reserved
#ifndef __util_h__
#define __util_h__

void pause_short(void);
void pause_long(void);

void print_bytes(const unsigned char data[], int num_bytes);

#endif // __util_h__

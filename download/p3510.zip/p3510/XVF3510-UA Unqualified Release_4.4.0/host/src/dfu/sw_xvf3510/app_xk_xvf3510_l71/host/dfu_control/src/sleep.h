// Copyright (c) 2020, XMOS Ltd, All rights reserved
#ifndef __sleep_h__
#define __sleep_h__

void sleep_milliseconds(unsigned milliseconds);

#endif

#!/bin/sh
cp -v libusb/libusb/libusb.h \
  sw_xvf3510/app_xk_xvf3510_l71/host/dsp_control/libusb/Android
cp -v libusb/android/libs/arm64-v8a/libusb1.0.so \
  sw_xvf3510/app_xk_xvf3510_l71/host/dsp_control/libusb/Android/arm64-v8a

/* 
**
** 
// Copyright (c) 2017, Pawpaw Electronic Technology., Ltd, All rights reserved
// This software is used for Pawpaw Microphone Array Source Project
// Visit at <http://www.pawpaw.hk/> for more information
**
*/
/* һЩ��ʼ������*/


#ifndef _INIT_CONFIG_H_
#define _INIT_CONFIG_H_


extern int pa_device_select( int *playdevID,int *recdevID);

#endif